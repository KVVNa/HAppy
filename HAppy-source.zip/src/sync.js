import { createClient } from '@supabase/supabase-js';
import {mergeThreeWay,validateSnapshot,describePath} from './merge.js';
const $=id=>document.getElementById(id), app=window.Happy, LOCAL='18ji-no-mikata-v2';
const CONFIG_KEY='happy-cloud-config';
let client=null,user=null,epoch=0,busy=false,pendingTimer=null,meta=null,metaKey='',conflictContext=null;
let config=window.HAPPY_CONFIG||{};
try{config={...config,...JSON.parse(localStorage.getItem(CONFIG_KEY)||'{}')}}catch{}
function status(text,message){$('cloudStatus').textContent=text;if(message)$('cloudMessage').textContent=message}
function fail(error){console.warn('Cloud sync failed:',error?.code||error?.name||'connection');status('同期できません','端末には記録を残しています。接続設定・ログイン・通信状況を確認して「今すぐ同期」を押してください。')}
function persistMeta(){try{localStorage.setItem(metaKey,JSON.stringify(meta))}catch{throw new Error('同期の保存領域を確保できません。記録を書き出してください。')}}
function validConfig(c){try{const url=new URL(c.supabaseUrl);if(url.protocol!=='https:'||!/^[-a-z0-9]+\.supabase\.co$/.test(url.hostname)||url.pathname!=='/'||url.search||url.hash||url.username)return false;const k=c.publishableKey;if(typeof k!=='string')return false;if(k.startsWith('sb_publishable_')&&k.length>24)return true;if(k.startsWith('eyJ')){const payload=JSON.parse(atob(k.split('.')[1].replaceAll('-','+').replaceAll('_','/')));return payload.role==='anon'}return false}catch{return false}}
function userScope(id){return 'happy-user:'+new URL(config.supabaseUrl).hostname+':'+id}
function accountUI(){const signed=!!user;$('cloudLogin').hidden=!client||signed;$('cloudAccount').hidden=!signed;$('cloudIdentity').textContent=signed?'ログイン中：'+user.email:''}
async function setUser(session){
 const next=session?.user||null;if(user?.id===next?.id&&user!==null)return;
 epoch++;user=next;busy=false;conflictContext=null;if($('syncConflict').open)$('syncConflict').close();
 if(!user){app.switchScope(LOCAL);meta=null;accountUI();status(client?'ログイン待ち':'この端末に保存');return}
 app.switchScope(userScope(user.id));metaKey=app.scope()+':sync';
 try{meta=JSON.parse(localStorage.getItem(metaKey)||'null')}catch{meta=null}
 if(!meta){meta={base:app.snapshot(),pending:null};persistMeta()}
 accountUI();status('同期を確認中');await synchronize();
}
async function connect(){
 $('cloudUrl').value=config.supabaseUrl||'';$('cloudKey').value=config.publishableKey||'';
 if(!validConfig(config)){app.switchScope(LOCAL);status('初回設定が必要','Supabaseの準備ができたら「初回の接続設定」を入力してください。今はこの端末で使えます。');return}
 client=createClient(config.supabaseUrl,config.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
 const {data,error}=await client.auth.getSession();if(error){fail(error);accountUI();return}
 await setUser(data.session);accountUI();
 client.auth.onAuthStateChange((_event,session)=>{setTimeout(()=>setUser(session).catch(fail),0)});
 $('cloudSetup').open=false;
}
function showConflicts(base,local,remote,conflicts,labels=['この端末','クラウド']){
 conflictContext={base,local,remote};
 const box=$('conflictList');box.replaceChildren();
 for(const item of conflicts){const section=document.createElement('section');section.className='history-entry';const title=document.createElement('h3');title.textContent=describePath(item.path);section.append(title);
  for(const side of ['local','remote']){const label=document.createElement('label');label.style.cssText='display:flex;gap:10px;align-items:flex-start;margin-top:10px';const radio=document.createElement('input');radio.type='radio';radio.name=item.path;radio.value=side;radio.checked=side==='local';radio.style.cssText='width:20px;flex-shrink:0';const text=document.createElement('span');text.style.cssText='font-size:12px;white-space:pre-wrap;overflow-wrap:anywhere';text.textContent=labels[side==='local'?0:1]+'：'+(typeof item[side]==='string'?item[side]:JSON.stringify(item[side]));label.append(radio,text);section.append(label)}
  box.append(section)
 }
 status('内容を選んでください','両方の変更を保持しています。競合している部分だけ確認してください。');
 if(!$('syncConflict').open)$('syncConflict').showModal();
}
function drainPending(){
 if(!meta?.pending)return true;
 if(app.editing())return false;
 const {local,remote}=meta.pending,current=app.snapshot();
 const merged=mergeThreeWay(local,current,remote);
 if(merged.conflicts.length){showConflicts(local,current,remote,merged.conflicts);return false}
 validateSnapshot(merged.value);app.apply(merged.value);meta.base=remote;meta.pending=null;persistMeta();return true
}
async function synchronize(){
 if(!client||!user||busy||conflictContext)return;
 if(!navigator.onLine){status('オフライン','端末に保存しています。通信が戻ると同期します。');return}
 if(app.editing())return;
 busy=true;const token=epoch,id=user.id;
 try{
  if(!drainPending())return;
  for(let attempt=0;attempt<3;attempt++){
   const {data:row,error}=await client.from('happy_state').select('payload,revision').eq('user_id',id).maybeSingle();
   if(token!==epoch)return;if(error)throw error;
   if(app.editing())return;
   const local=validateSnapshot(app.snapshot());
   let payload,revision;
   if(row){
    validateSnapshot(row.payload);const merged=mergeThreeWay(meta.base,local,row.payload);
    if(merged.conflicts.length){showConflicts(meta.base,local,row.payload,merged.conflicts);return}
    payload=validateSnapshot(merged.value);revision=row.revision;
    if(JSON.stringify(payload)===JSON.stringify(row.payload)){
     meta.pending={local,remote:payload};persistMeta();
     if(drainPending())status('同期済み','スマホ・PCで同じ記録を使えます。最終確認 '+new Date().toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit'}));return
    }
   }else payload=local;
   status('同期中');
   const write=row?
    client.from('happy_state').update({payload,revision:revision+1}).eq('user_id',id).eq('revision',revision).select('revision'):
    client.from('happy_state').insert({user_id:id,payload,revision:1}).select('revision');
   const {data:written,error:writeError}=await write;
   if(token!==epoch)return;
   if(writeError?.code==='23505'||(!writeError&&!written?.length))continue;
   if(writeError)throw writeError;
   // Preserve edits made during the HTTP request; apply them after leaving the input.
   meta.pending={local,remote:payload};persistMeta();
   if(drainPending())status('同期済み','メモとチェックを同期しました。'+new Date().toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit'}));
   else if(!conflictContext)status('入力後に同期を反映');
   return;
  }
  status('もう一度同期します','ほかの端末の変更を確認しています。記録はこの端末に残っています。');
 }catch(error){fail(error)}finally{if(token===epoch)busy=false}
}
$('resolveConflict').onclick=()=>{
 if(!conflictContext)return;
 try{
  const choices=Object.fromEntries(Array.from($('conflictList').querySelectorAll('input:checked')).map(x=>[x.name,x.value]));
  const c=conflictContext,result=mergeThreeWay(c.base,app.snapshot(),c.remote,choices);
  if(result.conflicts.length){showConflicts(c.base,app.snapshot(),c.remote,result.conflicts);return}
  validateSnapshot(result.value);app.apply(result.value);meta.base=c.remote;meta.pending=null;persistMeta();conflictContext=null;$('syncConflict').close();synchronize();
 }catch(error){fail(error)}
};
$('cancelConflict').onclick=()=>{$('syncConflict').close();status('競合を保留中','記録は残っています。「今すぐ同期」で、もう一度内容を選べます。')};
$('syncConflict').addEventListener('cancel',()=>status('競合を保留中','「今すぐ同期」で内容を選べます。'));
$('syncNow').onclick=()=>{if(conflictContext){$('syncConflict').showModal();return}synchronize()};
window.addEventListener('happy:change',()=>{clearTimeout(pendingTimer);pendingTimer=setTimeout(synchronize,1400)});
window.addEventListener('online',synchronize);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)synchronize()});
document.addEventListener('focusout',()=>{clearTimeout(pendingTimer);pendingTimer=setTimeout(synchronize,600)});
setInterval(()=>{if(!document.hidden)synchronize()},20000);
$('cloudConfigForm').onsubmit=e=>{
 e.preventDefault();if(user){app.toast('接続先を変える前に、ログアウトしてください。');return}
 const value={supabaseUrl:$('cloudUrl').value.trim().replace(/\/$/,''),publishableKey:$('cloudKey').value.trim()};
 if(!validConfig(value)){app.toast('SupabaseのProject URLとPublishable keyを確認してください。');return}
 try{localStorage.setItem(CONFIG_KEY,JSON.stringify(value));location.reload()}catch{app.toast('設定を保存できませんでした。')}
};
$('loginForm').onsubmit=async e=>{
 e.preventDefault();if(!client)return;
 if(location.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(location.hostname)){app.toast('ログインは公開されたHTTPSのページで行ってください。');return}
 const button=$('sendLink');button.disabled=true;
 try{
  const email=$('loginEmail').value.trim();
  const {error}=await client.auth.signInWithOtp({email,options:{emailRedirectTo:location.origin+location.pathname,shouldCreateUser:true}});
  if(error)throw error;
  status('メールを確認してください','届いたログインリンクを、この端末で開いてください。');
 }catch(error){status('メールを送れませんでした','メールアドレスとSupabaseのメール設定を確認してください。少し待って再試行できます。')}
 finally{setTimeout(()=>{button.disabled=false},60000)}
};
$('signOut').onclick=async()=>{
 if(!client)return;const {error}=await client.auth.signOut({scope:'local'});if(error){fail(error);return}await setUser(null);app.toast('ログアウトしました。未同期の記録は、この端末の同じアカウントに残っています。')
};
$('importLocal').onclick=()=>{
 try{
  if(!user)return;const source=app.localSnapshot();if(!source){app.toast('取り込む端末内の記録はありません。');return}
  validateSnapshot(source);
  // Absent base makes overlapping values explicit conflicts, never silent replacement.
  const current=app.snapshot(),merged=mergeThreeWay(null,source,current);
  if(merged.conflicts.length){showConflicts(null,source,current,merged.conflicts,['取り込む記録','現在の記録']);conflictContext.importSource=source;return}
  app.apply(validateSnapshot(merged.value));app.toast('端末の記録を取り込みました。');synchronize();
 }catch(error){fail(error)}
};
$('importFile').onchange=async()=>{
 const file=$('importFile').files[0];if(!file)return;
 try{
  if(busy||conflictContext){app.toast('同期または内容の選択が終わってから取り込んでください。');return}
  if(file.size>5000000)throw new Error('File too large');
  const input=JSON.parse(await file.text());
  const source=validateSnapshot({version:input.version,settings:input.settings,days:input.days});
  const current=app.snapshot(),merged=mergeThreeWay(null,source,current);
  if(merged.conflicts.length){showConflicts(null,source,current,merged.conflicts,['ファイルの記録','現在の記録']);conflictContext.importSource=source;return}
  app.apply(validateSnapshot(merged.value));app.toast('記録ファイルを取り込みました。');synchronize();
 }catch{app.toast('このファイルを取り込めませんでした。HAppyから書き出したJSONを選んでください。')}
 finally{$('importFile').value=''}
};
// During import the left-hand side is the saved local-only account, not the cloud account.
const resolveRegular=$('resolveConflict').onclick;
$('resolveConflict').onclick=()=>{
 if(!conflictContext?.importSource)return resolveRegular();
 try{
  const c=conflictContext,choices=Object.fromEntries(Array.from($('conflictList').querySelectorAll('input:checked')).map(x=>[x.name,x.value]));
  const result=mergeThreeWay(null,c.importSource,app.snapshot(),choices);
  if(result.conflicts.length){app.toast('内容を選んでください。');return}
  app.apply(validateSnapshot(result.value));conflictContext=null;$('syncConflict').close();synchronize();
 }catch(error){fail(error)}
};
connect().catch(fail);

