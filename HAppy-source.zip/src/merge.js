const MISSING=Symbol('missing');
const equal=(a,b)=>a===b||(a!==MISSING&&b!==MISSING&&JSON.stringify(a)===JSON.stringify(b));
const record=x=>x!==MISSING&&x!==null&&typeof x==='object'&&!Array.isArray(x);
const esc=x=>x.replaceAll('~','~0').replaceAll('/','~1');
export function mergeThreeWay(base,local,remote,choices={}){
 const conflicts=[];
 function walk(b,l,r,path){
  if(equal(l,r))return l;
  if(equal(l,b))return r;
  if(equal(r,b))return l;
  if(record(l)&&record(r)&&(record(b)||b===MISSING)){
   const out={};for(const key of new Set([...Object.keys(b===MISSING?{}:b),...Object.keys(l),...Object.keys(r)])){
    if(['__proto__','constructor','prototype'].includes(key))throw new Error('Invalid data key');
    const v=walk(b!==MISSING&&Object.hasOwn(b,key)?b[key]:MISSING,Object.hasOwn(l,key)?l[key]:MISSING,Object.hasOwn(r,key)?r[key]:MISSING,path+'/'+esc(key));
    if(v!==MISSING)out[key]=v;
   }return out;
  }
  // Three fixed task slots can merge independently. Routine order is kept atomic.
  if(path.endsWith('/tasks')&&Array.isArray(l)&&Array.isArray(r)&&l.length===3&&r.length===3){return l.map((v,i)=>walk(Array.isArray(b)?b[i]:MISSING,v,r[i],path+'/'+i))}
  if(choices[path]==='local')return l;
  if(choices[path]==='remote')return r;
  conflicts.push({path,local:l===MISSING?null:l,remote:r===MISSING?null:r});return r;
 }
 return{value:walk(base??MISSING,local,remote,''),conflicts};
}

export function validateSnapshot(value){
 const fail=()=>{throw new Error('保存データの形式を確認できませんでした。元の記録は変更していません。')};
 if(!record(value)||value.version!==2||!record(value.settings)||!record(value.days))fail();
 const walk=v=>{if(v&&typeof v==='object')for(const [k,x]of Object.entries(v)){if(['__proto__','constructor','prototype'].includes(k))fail();walk(x)}};walk(value);
 const s=value.settings,t=/^(?:[01]\d|2[0-3]):[0-5]\d$/;
 if(!t.test(s.start)||!t.test(s.end)||s.end<=s.start||!Array.isArray(s.routine)||!s.routine.length||s.routine.length>12)fail();
 for(const [k,max]of [['commute',240],['arrival',120],['breaks',480]])if(!Number.isInteger(s[k])||s[k]<0||s[k]>max)fail();
 if(!Number.isFinite(s.sleep)||s.sleep<4||s.sleep>12||typeof s.place!=='string'||typeof s.reward!=='string')fail();
 if(!Array.isArray(s.weekdays)||!s.weekdays.length||s.weekdays.some(v=>!Number.isInteger(v)||v<0||v>6))fail();
 if(s.routine.some(r=>!record(r)||typeof r.id!=='string'||typeof r.name!=='string'||!Number.isInteger(r.min)||r.min<1||r.min>180))fail();
 const mins=v=>Number(v.slice(0,2))*60+Number(v.slice(3));
 if(mins(s.start)-s.commute-s.arrival-s.routine.reduce((a,r)=>a+r.min,0)<0||s.breaks>=mins(s.end)-mins(s.start))fail();
 const date=/^\d{4}-\d{2}-\d{2}$/;
 for(const[k,d]of Object.entries(value.days)){
  if(!date.test(k)||!record(d)||!record(d.morning)||Object.values(d.morning).some(v=>typeof v!=='boolean')||!Array.isArray(d.tasks)||d.tasks.length!==3)fail();
  if(d.tasks.some(t=>!record(t)||typeof t.text!=='string'||typeof t.done!=='boolean'))fail();
  if(!record(d.note)||!date.test(d.note.target)||['next','loose','win'].some(k=>typeof d.note[k]!=='string'))fail();
  if(!record(d.night)||Object.values(d.night).some(v=>typeof v!=='boolean')||typeof d.reward!=='string'||typeof d.enjoyed!=='boolean'||typeof d.finished!=='boolean'||!Number.isInteger(d.focus)||d.focus<0)fail();
 }
 if(JSON.stringify(value).length>4000000)throw new Error('記録が大きくなっています。書き出して保管してください。');
 return value;
}

export function describePath(path){const labels={settings:'時間の設定',days:'日ごとの記録',tasks:'大事な3つ',text:'内容',done:'完了',morning:'朝の準備',note:'明日のメモ',next:'最初の一手',loose:'続き',win:'できたこと',reward:'ご褒美',enjoyed:'楽しんだ',finished:'退勤',night:'夜の準備',focus:'集中回数',routine:'朝の順番',start:'始業',end:'退勤時刻',commute:'通勤時間',arrival:'到着後の余裕',breaks:'休憩',sleep:'睡眠',place:'仕事の場所',weekdays:'仕事の日',target:'メモの日付'};return path.split('/').filter(Boolean).map(x=>labels[x]||x).join(' / ')}
