import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
test('schema restricts each authenticated user to their own row',()=>{const sql=fs.readFileSync('supabase/setup.sql','utf8');assert.match(sql,/enable row level security/i);assert.match(sql,/revoke all on public.happy_state from anon/i);assert.equal((sql.match(/auth.uid\(\)\) = user_id/g)||[]).length,4);assert.match(sql,/NEW.revision <> OLD.revision \+ 1/);assert.doesNotMatch(sql,/grant[^;]*to anon/i)});
test('public config has no credentials',()=>{const config=fs.readFileSync('site/config.js','utf8');assert.match(config,/supabaseUrl: \"\", publishableKey: \"\"/);assert.doesNotMatch(config,/sb_secret_|eyJ[A-Za-z0-9_-]{30}/)});

