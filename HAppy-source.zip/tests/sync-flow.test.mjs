import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {mergeThreeWay,validateSnapshot,describePath} from '../src/merge.js';
const initial=()=>({version:2,settings:{start:'07:50',end:'18:00',commute:40,arrival:5,breaks:60,sleep:8,place:'',reward:'本',weekdays:[1],routine:[{id:'wake',name:'準備',min:45}]},days:{}});
function setup(){
 const elements=new Map(),storage=new Map();let local=initial(),editing=false;
 const element=id=>{if(!elements.has(id))elements.set(id,{textContent:'',hidden:false,open:false,addEventListener(){},replaceChildren(){},append(){},showModal(){this.open=true},close(){this.open=false}});return elements.get(id)};
 const cloud={row:{payload:initial(),revision:1},attempts:0,beforeWrite:null};
 const client={from(){return {
  select(){return {eq(){return {maybeSingle:async()=>({data:structuredClone(cloud.row),error:null})}}}},
  update(value){let expected;return {
   eq(key,val){if(key==='revision')expected=val;return this},
   async select(){
    cloud.attempts++;
    if(cloud.beforeWrite)await cloud.beforeWrite();
    if(cloud.row.revision!==expected)return {data:[],error:null};
    cloud.row={payload:structuredClone(value.payload),revision:value.revision};
    return {data:[{revision:value.revision}],error:null};
   }
  }}
 }}};
 const app={snapshot:()=>structuredClone(local),apply:data=>{local=structuredClone(data)},editing:()=>editing,toast(){},scope:()=> 'test',switchScope(){}};
 const ctx=vm.createContext({window:{Happy:app,HAPPY_CONFIG:{},addEventListener(){}},document:{getElementById:element,addEventListener(){},createElement:()=>({style:{},append(){}})},navigator:{onLine:true},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},console,URL,setTimeout:()=>0,clearTimeout(){},setInterval(){},mergeThreeWay,validateSnapshot,describePath});
 const source=fs.readFileSync('src/sync.js','utf8').replace(/^import .*;\r?\n/gm,'').replace('connect().catch(fail);','');
 vm.runInContext(source+'\nglobalThis.harness={prepare(c,b){client=c;user={id:"u"};meta={base:b,pending:null};metaKey="test-meta"},sync:synchronize,meta:()=>meta,conflict:()=>conflictContext,invalidate(){epoch++}};',ctx);
 ctx.harness.prepare(client,initial());
 return{h:ctx.harness,cloud,element,get local(){return local},set local(v){local=v},setEditing:x=>{editing=x}};
}
test('revision race retries and preserves both device updates',async()=>{const a=setup();a.local.settings.place='別室';a.cloud.beforeWrite=async()=>{if(a.cloud.attempts===1){a.cloud.row.payload.settings.reward='アイス';a.cloud.row.revision++}};await a.h.sync();assert.equal(a.cloud.attempts,2);assert.equal(a.cloud.row.payload.settings.place,'別室');assert.equal(a.cloud.row.payload.settings.reward,'アイス');assert.equal(a.local.settings.reward,'アイス')});
test('typing during write is kept, then pushed on next sync',async()=>{const a=setup();a.local.settings.place='別室';a.cloud.beforeWrite=async()=>{a.local.settings.reward='入力中';a.setEditing(true)};await a.h.sync();assert.ok(a.h.meta().pending);assert.equal(a.local.settings.reward,'入力中');a.cloud.beforeWrite=null;a.setEditing(false);await a.h.sync();assert.equal(a.cloud.row.payload.settings.reward,'入力中');assert.equal(a.local.settings.place,'別室')});
test('same field conflict stops writes and keeps local content',async()=>{const a=setup();a.local.settings.place='PC';a.cloud.row.payload.settings.place='スマホ';await a.h.sync();assert.equal(a.cloud.attempts,0);assert.ok(a.h.conflict());assert.equal(a.local.settings.place,'PC');assert.equal(a.cloud.row.payload.settings.place,'スマホ')});
test('response after account switch cannot update new local state',async()=>{const a=setup();a.local.settings.place='別室';a.cloud.beforeWrite=async()=>{a.h.invalidate();a.local=initial();a.local.settings.reward='別アカウント'};await a.h.sync();assert.equal(a.local.settings.reward,'別アカウント');assert.equal(a.local.settings.place,'')});
