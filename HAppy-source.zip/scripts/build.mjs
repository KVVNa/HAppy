import { build } from 'esbuild';
import { cp, mkdir } from 'node:fs/promises';
await mkdir('dist',{recursive:true});
await cp('site','dist',{recursive:true});
await build({entryPoints:['src/sync.js'],bundle:true,minify:true,format:'iife',platform:'browser',target:['es2022'],outfile:'dist/sync.js'});
console.log('Built dist/ for GitHub Pages.');

